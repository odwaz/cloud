package com.example.shoppingcart;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.view.View;
import android.view.View.OnClickListener;

public class MainActivity extends Activity {

	Button button;
	Button button1;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		addListenerOnButton();
		addListenerOnButtons();
		addListenerOnItemsButton();
		//addListenerOnButtonOptions();
		
		
		 Button btn1 = (Button) findViewById(R.id.btnExit);
		    btn1.setOnClickListener(new OnClickListener() {

		        @Override
		        public void onClick(View v) {
		            // TODO Auto-generated method stub
		            finish();
		            System.exit(0);
		        }
		    });

	}

	public void addListenerOnButton() {

		final Context context = this;
		button = (Button) findViewById(R.id.btnGoNewList);
		button.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(context, list_activity.class);
				startActivity(intent);
			}
		});

	}
	
	
	
	
	public void addListenerOnButtons() {

		final Context context = this;
		button1 = (Button) findViewById(R.id.btnGoListOfShops);
		button1.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(context,shop_activity.class);
				startActivity(intent);
			}
		});

	}
	
	public void addListenerOnItemsButton() {

		final Context context = this;
		button1 = (Button) findViewById(R.id.btnGoListOfItems);
		button1.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(context,options_list.class);
				startActivity(intent);
			}
		});

	}
	
	/*
	 
	 
	  public void addListenerOnButtonOptions() {

		final Context context = this;
		Button buttons = (Button) findViewById(R.id.btnGoOptions);
	    buttons.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(context, list_activity.class);
				startActivity(intent);
			}
		});

	}*/

}
