package com.example.shoppingcart;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Button;

public class list_activity extends Activity {

	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.new_list);
	}

}